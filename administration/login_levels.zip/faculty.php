<html>
  <head>
    <title> Faculty Page </title>
 <head>
  <style>
    body {
	  font-family:arial;
	  background-color : green;
	  color:yellow;
	 };
	</style>
<body><br>
 <h1 align="center">
  Welcome To Faculty Page 
  </h1>
 </body>
 </html>
 
 

	
 
 