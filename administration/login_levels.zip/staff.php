<html>
  <head>
    <title> Staff Page </title>
 <head>
  <style>
    body {
	  font-family:arial;
	  background-color : pink;
	  color:yellow;
	 };
	</style>
<body><br>
 <h1 align="center">
  Welcome To Staff Page 
  </h1>
 </body>
 </html>
 
 

	
 
 