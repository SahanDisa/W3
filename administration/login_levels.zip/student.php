<html>
  <head>
    <title> Student Page </title>
 <head>
  <style>
    body {
	  font-family:arial;
	  background-color : yellow;
	  color:blue;
	 };
	</style>
<body><br>
 <h1 align="center">
  Welcome To Student Page 
  </h1>
 </body>
 </html>
 
 

	
 
 